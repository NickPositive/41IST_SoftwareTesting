const { asyncError } = require('../src/labAssignment-lab4');

describe('asyncError', () => {
  test('rejects with "Something went wrong" error', async () => {
    await expect(asyncError()).rejects.toThrow('Something went wrong');
  });
});