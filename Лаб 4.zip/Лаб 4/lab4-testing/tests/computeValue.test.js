const { computeValue } = require('../src/labAssignment-lab4');

describe('computeValue', () => {
  test('returns 94', async () => {
    const result = await computeValue();
    expect(result).toBe(94);
  });
});