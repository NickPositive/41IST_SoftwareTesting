const { UserService } = require('../src/labAssignment-lab4');

describe('UserService', () => {
  test('greet() calls getFullName with "John" and "Doe" and returns uppercase greeting', () => {
    const mockGetFullName = jest.fn((firstName, lastName) => `${firstName} ${lastName}`);
    const userService = new UserService(mockGetFullName);
    
    const result = userService.greet();
    
    expect(mockGetFullName).toHaveBeenCalledWith('John', 'Doe');
    expect(result).toBe('HELLO, JOHN DOE!');
  });
});