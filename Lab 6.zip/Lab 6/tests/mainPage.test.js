// mainPage.test.js
const { Builder, By, until, Key } = require('selenium-webdriver');

let driver;

beforeAll(async () => {
    driver = await new Builder().forBrowser('chrome').build();
    jest.setTimeout(30000);
});

afterAll(async () => {
    await driver.quit();
});

test('Відкривається головна сторінка', async () => {
    await driver.get('https://automationexercise.com/'); 
    await driver.wait(until.elementLocated(By.css('body')), 10000);
});
  
test('Перевірка елементів головної сторінки', async () => {
    const navMenu = await driver.findElement(By.css('ul.nav.navbar-nav'));
    expect(await navMenu.isDisplayed()).toBe(true);
  
    const logo = await driver.findElement(By.xpath("//img[contains(@src,'logo')]"));
    expect(await logo.isDisplayed()).toBe(true);
  
    const altText = await logo.getAttribute('alt');
    expect(altText).toMatch(/automation practice/i);       
  
    const signupBtn = await driver.findElement(By.linkText('Signup / Login'));
    expect(await signupBtn.isDisplayed()).toBe(true);
  
    const btnText = await signupBtn.getText();
    expect(btnText).toContain('Signup');
});
  
