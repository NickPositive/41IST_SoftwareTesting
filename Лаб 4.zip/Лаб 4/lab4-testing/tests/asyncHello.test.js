const { asyncHello } = require('../src/labAssignment-lab4');

describe('asyncHello', () => {
  test('resolves with "hello world"', async () => {
    await expect(asyncHello()).resolves.toBe('hello world');
  });
});