const { ApiHelper } = require('../src/labAssignment-lab4');

describe('ApiHelper', () => {
  test('fetchViaHelper returns data from apiCallFunction', async () => {
    const mockData = { test: 'data' };
    const mockApiCall = jest.fn(() => Promise.resolve(mockData));
    const apiHelper = new ApiHelper();
    
    const result = await apiHelper.fetchViaHelper(mockApiCall);
    
    expect(mockApiCall).toHaveBeenCalled();
    expect(result).toEqual(mockData);
  });

  test('fetchViaHelper throws error for invalid data', async () => {
    const mockApiCall = jest.fn(() => Promise.resolve(null));
    const apiHelper = new ApiHelper();
    
    await expect(apiHelper.fetchViaHelper(mockApiCall)).rejects.toThrow('Invalid data');
  });
});