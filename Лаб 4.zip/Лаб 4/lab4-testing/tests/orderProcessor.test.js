const { OrderProcessor } = require('../src/labAssignment-lab4');

describe('OrderProcessor', () => {
  const mockConverter = jest.fn((amount, from, to) => {
    if (to === 'EUR') return amount * 0.85;
    throw new Error('Unsupported currency');
  });

  const validOrder = {
    items: [
      { price: 10, quantity: 2 }
    ],
    taxRate: 0.1,
    currency: 'USD'
  };

  test('processOrder converts currency when converter is available', async () => {
    const processor = new OrderProcessor(mockConverter);
    const result = await processor.processOrder(validOrder, 'EUR');
    expect(result).toBe(18.7);
    expect(mockConverter).toHaveBeenCalledWith(22, 'USD', 'EUR');
  });

  test('processOrder returns original price when converter fails', async () => {
    const processor = new OrderProcessor(mockConverter);
    const result = await processor.processOrder(validOrder, 'GBP');
    expect(result).toBe(22);
  });

  test('processOrder returns original price when no target currency', async () => {
    const processor = new OrderProcessor(mockConverter);
    const result = await processor.processOrder(validOrder);
    expect(result).toBe(22);
  });
});